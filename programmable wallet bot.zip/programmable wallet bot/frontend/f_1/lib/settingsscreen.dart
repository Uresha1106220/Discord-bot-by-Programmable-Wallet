import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text(
              'Account Information',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Text(
              'Username: [Username]',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Email: [Email]',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Password: [Password]',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 40),
            Text(
              'Currency Settings',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            DropdownButton(
              value: 'BTC',
              onChanged: (value) {
                // Update default currency
              },
              items: [
                DropdownMenuItem(
                  child: Text('BTC'),
                  value: 'BTC',
                ),
                DropdownMenuItem(
                  child: Text('ETH'),
                  value: 'ETH',
                ),
                // Add more currencies
              ],
            ),
            SizedBox(height: 40),
            Text(
              'Notification Settings',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Switch(
              value: true,
              onChanged: (value) {
                // Update notification settings
              },
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                // Logout
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}