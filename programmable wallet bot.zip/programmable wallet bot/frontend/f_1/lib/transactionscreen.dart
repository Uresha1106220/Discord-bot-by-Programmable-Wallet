import 'package:flutter/material.dart';

class SendTransactionScreen extends StatefulWidget {
  @override
  _SendTransactionScreenState createState() => _SendTransactionScreenState();
}

class _SendTransactionScreenState extends State<SendTransactionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Send Transaction'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text(
              'Transaction Details',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Text(
              'From: Your Wallet',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'To: [Recipient\'s Wallet Address]',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Amount: [Amount] BTC',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Fee: [Fee] BTC',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                // Confirm transaction
              },
              child: Text('Confirm'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Cancel transaction
              },
              child: Text('Cancel'),
            ),
          ],
        ),
      ),
    );
  }
}