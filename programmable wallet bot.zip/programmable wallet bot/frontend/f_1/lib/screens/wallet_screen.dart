import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class WalletScreen extends StatefulWidget {
  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final _formKey = GlobalKey<FormState>();
  final _walletAddressController = TextEditingController();
  final _amountController = TextEditingController();

  Future<void> _sendTransaction() async {
    final walletAddress = _walletAddressController.text;
    final amount = _amountController.text;

    try {
      final response = await http.post(
        Uri.parse('http://localhost:3000/send-transaction'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'walletAddress': walletAddress,
          'amount': amount,
        }),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Transaction sent successfully')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error sending transaction')),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error sending transaction')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Discord Bot Wallet'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _walletAddressController,
                decoration: InputDecoration(
                  labelText: 'Wallet Address',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a wallet address';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _amountController,
                decoration: InputDecoration(
                  labelText: 'Amount',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an amount';
                  }
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: _sendTransaction,
                child: Text('Send Transaction'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}