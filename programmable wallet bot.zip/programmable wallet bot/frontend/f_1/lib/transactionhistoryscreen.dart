import 'package:flutter/material.dart';

class TransactionHistoryScreen extends StatefulWidget {
  @override
  _TransactionHistoryScreenState createState() => _TransactionHistoryScreenState();
}

class _TransactionHistoryScreenState extends State<TransactionHistoryScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Transaction History'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView.builder(
          itemCount: 10,
          itemBuilder: (context, index) {
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'Date: [Date]',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Type: [Type] (Send/Receive)',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Amount: [Amount] BTC',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Fee: [Fee] BTC',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Status: [Status] (Pending/Confirmed)',
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}