const express = require('express');
const app = express();
const Discord = require('discord.js');
const walletAPI = require('./walletAPI');

app.use(express.json());

const discordBot = new Discord.Client();
   // Make sure to replace YOUR_DISCORD_BOT_TOKEN with your actual Discord bot token
discordBot.login('YOUR_DISCORD_BOT_TOKEN');

app.post('/send-transaction', async (req, res) => {
  const walletAddress = req.body.walletAddress;
  const amount = req.body.amount;

  try {
    // Call the wallet API to send the transaction
    const response = await walletAPI.sendTransaction(walletAddress, amount);

    res.status(200).send({ message: 'Transaction sent successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error sending transaction' });
  }
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});